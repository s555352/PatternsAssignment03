package overridenMethods;
/**
 * 
 * @author S555352 Asritha Baddam
 */
public class SubClass extends SuperClass {
	@Override
	public void publicMethod() {
		System.out.println("This is a new implementation of the public method");
	}
	// Cannot increase the visibility of the method
	// Error: attempting to assign weaker access privileges
	// protected void publicMethod() {}
	@Override
	protected void protectedMethod() {
		System.out.println("This is a new implementation of the protected method");
	}
	@Override
	void defaultMethod() {
		System.out.println("This is a new implementation of the default method");
	}
	// Cannot reduce the visibility of the method
	// Error: attempting to assign weaker access privileges
	// @Override
	// public void protectedMethod() {}

	// Cannot override private methods in a subclass
	// Error: privateMethod() has private access in SuperClass
	// @Override
	// private void privateMethod() {}
}
