package overridenMethods;

/**
 * 
 * @author S555352 Asritha Baddam
 */

public class SuperClass {	
	public void publicMethod() {
		System.out.println("This method is public");
	}
	protected void protectedMethod() {
		System.out.println("This method is protected");
	}
	void defaultMethod() {
		System.out.println("This method is default");
	}
	private void privateMethod() {
		System.out.println("This method is private");
	}
}
