package TryWithoutCatchTest;
/**
 * 
 * @author S555352 Asritha Baddam
 */
public class TryWithOutCatchBlockTest {
	/**
	 * 
	 * @param args
	 */

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			System.out.println("Try block executes here.");
		} finally {
			System.out.println("Finally block executes all the time.");
		}

	}

}
