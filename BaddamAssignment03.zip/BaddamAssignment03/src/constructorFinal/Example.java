package constructorFinal;

/**
 * 
 * @author S555352 Asritha Baddam
 */

public class Example {
	private double idNum;
	private String lastName;
	
	public final Example() {
		this.idNum = idNum;
		this.lastName = lastName;
}
}