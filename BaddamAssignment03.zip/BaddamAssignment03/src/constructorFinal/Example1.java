package constructorFinal;

/**
 * 
 * @author S555352 Asritha Baddam
 */

public final class Example1 {
	
	private double idNum;
	private String lastName;
	private Example1(double idNum, String lastName) {
		super();
		this.idNum = idNum;
		this.lastName = lastName;
	}
	

}
