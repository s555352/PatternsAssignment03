package CovariantDemo;
/**
 * 
 * @author S555352 Asritha Baddam
 */
public class CovariantDriver {
	
	/**
	 * 
	 * @param args
	 */

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Mammal().getInstance().move();

	}

}
