package CovariantDemo;

/**
 * 
 * @author S555352 Asritha Baddam
 */

public class Animal {
	public Animal getInstance() {
		return this;
	}
	public void move() {
		System.out.println("Animal is producing");
	}
}
