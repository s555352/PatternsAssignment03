package GarbageCollectionTest;

public class GarbageCollectionDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
        // Create a large number of objects
        for (int i = 0; i < 1000000; i++) {
            new Object();
        }
        
        // Explicitly call the garbage collector
        System.gc();
        
        // Wait for a moment to allow the garbage collector to run
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        
        System.out.println("Garbage collection completed.");


	}

}
