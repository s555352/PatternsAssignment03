package Generics;

/**
 * 
 * @author S555352 Asritha Baddam
 */

public class genericsDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		genericsClass<String> stringClass = new genericsClass<>("Hi, Everyone!");
		String detail = stringClass.getDetail();

	}

}
