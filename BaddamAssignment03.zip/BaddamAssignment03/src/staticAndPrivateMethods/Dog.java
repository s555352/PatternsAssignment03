package staticAndPrivateMethods;
/**
 * 
 * @author S555352 Asritha Baddam
 */
public class Dog extends Animal {
	public static void makeSound() {
		System.out.println("Dog is barking");
	}

}
