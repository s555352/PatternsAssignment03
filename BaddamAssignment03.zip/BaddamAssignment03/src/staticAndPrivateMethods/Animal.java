package staticAndPrivateMethods;
/**
 * 
 * @author S555352 Asritha Baddam
 */
public class Animal {
	public static void makeSound() {
		System.out.println("Animal makes sound");
	}
}
