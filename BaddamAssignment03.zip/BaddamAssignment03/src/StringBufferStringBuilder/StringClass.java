package StringBufferStringBuilder;
/**
 * 
 * @author S555352 Asritha Baddam
 */
public class StringClass {
	/**
	 * 
	 * @param args
	 */

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String st = new String("Hi ");
		st.concat(" Everyone");
		System.out.println(st);	
	}

}
