package StringBufferStringBuilder;
/**
 * 
 * @author S555352 Asritha Baddam
 */
public class StringBufferTest {
	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		StringBuffer buffer = new StringBuffer("Hello");
		buffer.append(" Friends!");
		System.out.println("StringBuffer Example: " + buffer);
	}

}
