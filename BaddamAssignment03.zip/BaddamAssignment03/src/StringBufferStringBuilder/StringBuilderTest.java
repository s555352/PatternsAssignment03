package StringBufferStringBuilder;
/**
 * 
 * @author S555352 Asritha Baddam
 */
public class StringBuilderTest {
	/**
	 * @param args
	 */

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuilder build = new StringBuilder("Hi");
		build.append(" Everyone!");
		System.out.println("StringBuilder Example: "+ build);
	}

}
