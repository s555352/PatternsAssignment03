package ThrowsClassDemo;
/**
 * 
 * @author S555352 Asritha Baddam
 */

public class SubClassDemo extends SuperClassDemo {
	/**
	 * 
	 * @param args
	 */

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		void msg() throws ArithmeticException{
			System.out.println("Hi");
		}

	}

}
